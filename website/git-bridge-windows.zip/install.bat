@echo off
echo Git Bridge Installer for Windows
echo ================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo Installing Python...
    echo Please download Python from https://python.org/downloads/
    echo Then run this installer again.
    pause
    exit /b 1
)

REM Check Git
git --version >nul 2>&1
if errorlevel 1 (
    echo Installing Git...
    echo Please download Git from https://git-scm.com/downloads
    echo Then run this installer again.
    pause
    exit /b 1
)

echo Creating Git Bridge directory...
mkdir "%USERPROFILE%\Git Bridge" 2>nul

echo Extracting files...
REM In a real installer, files would be extracted here

echo Installing dependencies...
cd "%USERPROFILE%\Git Bridge"
python -m venv venv
call venv\Scripts\activate.bat
pip install ttkbootstrap keyring markdown2

echo Creating desktop shortcut...
echo @echo off > "%USERPROFILE%\Desktop\Git Bridge.bat"
echo cd "%USERPROFILE%\Git Bridge" >> "%USERPROFILE%\Desktop\Git Bridge.bat"
echo call venv\Scripts\activate.bat >> "%USERPROFILE%\Desktop\Git Bridge.bat"
echo python main.py >> "%USERPROFILE%\Desktop\Git Bridge.bat"

echo.
echo Installation complete!
echo You can now run Git Bridge from your desktop.
pause
